create definer = root@localhost trigger tr_annonce_insert
    before INSERT
    on annonce
    for each row
BEGIN
	IF (NEW.date_creation IS NULL) THEN 
    SET NEW.date_creation = NOW();
    END IF;
    IF (NEW.date_limite IS NULL) THEN 
    SET NEW.date_limite = ADDDATE(CURDATE(), INTERVAL 21 DAY);
    END IF;
    END;

