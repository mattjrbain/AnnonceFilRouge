create
    definer = root@localhost procedure insertUser(IN in_nom varchar(30), IN in_prenom varchar(30),
                                                  IN in_mdp varchar(128))
INSERT INTO utilisateur (NOM, PRENOM, MDP)
VALUES (in_nom, in_prenom, in_mdp);

